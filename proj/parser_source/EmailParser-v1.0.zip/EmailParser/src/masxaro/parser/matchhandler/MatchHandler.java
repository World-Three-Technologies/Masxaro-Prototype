package masxaro.parser.matchhandler;

public abstract class MatchHandler {

}
