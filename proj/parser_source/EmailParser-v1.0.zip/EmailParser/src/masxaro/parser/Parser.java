package masxaro.parser;
import java.util.*;
import java.util.regex.*;
import java.io.*;

import masxaro.parser.entity.*;
import masxaro.parser.matchers.*;
import masxaro.parser.tool.*;
import masxaro.parser.saver.*;


public class Parser {
	private String userAcc;
	private File[] fileList;
	private ArrayList<Receipt> receipts;
	private String rootPath;
	
	Parser(String userAcc_init, String email_root, String log_path){
		this.userAcc = userAcc_init;
		this.receipts = new ArrayList<Receipt>();
		this.rootPath = email_root + "/" + this.userAcc;
		Log.setLogRoot(log_path);
	}
	
	protected void save() {
//		Saver saver = new FileSaver();
//		saver.set(this.rootPath, this.receipts);
//		saver.save();
		
		Saver saver = new DbSaver();
		saver.set(this.rootPath, this.receipts);
		saver.save();
	}
	
	protected void appendReceipt(Receipt receipt) {
		if(receipt.user_account == null) {
			receipt.user_account = this.userAcc;
		}
		
		this.receipts.add(receipt);
	}
	
	/**
	 * fetch PHP grabbed emails
	 */
	public boolean fetchNewEmails(){
		try{
			File target = new File(this.rootPath);
			if(target.isDirectory() && target.exists()){
				if((this.fileList = target.listFiles()) == null || this.fileList.length == 0){
					Log.writeLog("No emails in: " + this.rootPath);
					return false;
				}
				Log.writeLog("Fetch emails in: " + this.rootPath);
			}
			else{
				Log.writeLog("Cannot find directory: " + this.rootPath);
				return false;
			}
		}catch(Exception e){
			Log.writeLog("Fetch emails error: File error.");
			return false;
		}
		return true;
	}
	
	/**
	 * @todo delete file after parsed
	 * FDA(1)
	 * parse start
	 */
	public void parseEmails(){
		if(!this.fetchNewEmails()){
			return;
		}
		try{
			for(File file : this.fileList){
				String from = file.getName().split(":::")[0];
				Log.writeLog("Parsing " + file.getName() + " ...");
				this.parseReceipts(this.parseHTML(file), from);
				//Log.writeLog(file.getName() + " Parse done. Delete file");
				file.delete();
			}
			this.save();
			//this.parseReceipts(this.parseHTML(new File("mails/w3tAcc/test")));
		}catch(Exception e){
			Log.writeLog("Parse file exception.");
		}
		return;
	}
	
	/**
	 * FDA(2)
	 * @param File page html page
	 * 
	 * 
	 * @return ArrayList<String> pageEle all non-html, text elements with receipt informations
	 * 
	 * @desc
	 * this function will eliminate all html elements in an html file and pick out all text words
	 * and organize them into an arraylist.
	 */
	protected ArrayList<String> parseHTML(File file){
		ArrayList<String> pageEle = new ArrayList<String>();
		try{
			BufferedReader in = new BufferedReader(new FileReader(file));
			String tmp;
			StringBuilder page = new StringBuilder();
			while((tmp = in.readLine()) != null){
				page.append(tmp);
			}
			in.close();
			
			String curPage = page.toString();
			String regexp_receipt = ".*receipt.*";
			String regexp_order = ".*order.*";
			if(!curPage.matches(regexp_order) && curPage.matches(regexp_receipt)){
				return null;
			}
			
			String regexp = ">([^<>]+)<";
			Pattern reg = Pattern.compile(regexp);
			Matcher mtch = reg.matcher(curPage);
			while(mtch.find()){
				String cur = mtch.group();
				cur = cur.substring(1, cur.length() - 1).trim();
				if(cur == null || cur.length() == 0){
					continue;
				}
				pageEle.add(cur);
			}
		}catch(Exception e){
			Log.writeLog("ParseHTML error.");
			return null;
			//e.printStackTrace();
		}
		return pageEle;
	}
	
	/**
	 * FDA(3)
	 * @todo
	 * finish all patterns, cost patterns, and separately match different costs.
	 * 
	 * @param ArrayList<String> pageEle
	 * @param String from store account
	 * @return ArrayList<ReceiptEnty> receipts
	 * 
	 * @desc
	 * parse receipts from one parsed pageEle arraylist of one html email
	 */
	protected void parseReceipts(ArrayList<String> pageEle, String from){
		if(pageEle == null){
			return;
		}
		ArrayList<Matchers> matchers = new ArrayList<Matchers>();
		
		MatchersFactory matcherFac = new MatchersFactory();
		
		for(int i = 0; i < matcherFac.getMatchersNumber(); i ++){
			matchers.add(matcherFac.getMatcher(i));
		}
		
		boolean searchingInvoke = true;
		int curMatcherIndex = 0;
		Receipt curReceipt = null;
		
		for(int curEleIndex = 0; curEleIndex < pageEle.size(); curEleIndex ++){
			curMatcherIndex = searchingInvoke ? 0 : curMatcherIndex;
			for(; curMatcherIndex < matchers.size();){
				if(searchingInvoke){
					if(matchers.get(curMatcherIndex).match(pageEle.get(curEleIndex), true, false)){
						searchingInvoke = false;
						curEleIndex --;
						break;
					}
					curMatcherIndex ++;
				}
				else{
					if(matchers.get(curMatcherIndex).match(pageEle.get(curEleIndex), false, false)){
						if(curReceipt != null){
							curReceipt.store_account = from;
						}
						curReceipt = valueHandler(matchers.get(curMatcherIndex), pageEle, curReceipt, curEleIndex);
						searchingInvoke = true;
					}
					break;
				}
			}
		}
		
		if(curReceipt != null){
			this.appendReceipt(curReceipt);
		}
	}
	
	/**
	 * FDA(4)
	 * handling logic after value matched
	 */
	protected Receipt valueHandler(Matchers matcher, ArrayList<String> pageEle, Receipt curReceipt, int curEleIndex){
		String[] tmp;
		
		String curEle = pageEle.get(curEleIndex);
		
		String matcherName = matcher.getClass().getName();
		matcherName = matcherName.substring(matcherName.lastIndexOf(".") + 1, matcherName.length());
		
		if(matcherName.equals("ReceiptNoMatcher")){
			tmp = curEle.split(":");
			String number = tmp[tmp.length - 1].trim();
			
			if(curReceipt != null){
				if(curReceipt.store_define_id == null){
					curReceipt.store_define_id  = number;
				}
				if(!curReceipt.items.isEmpty()){
					this.appendReceipt(curReceipt);
					curReceipt = null;
				}
			}
			
			if(curReceipt == null){
				curReceipt = new Receipt();
				curReceipt.store_define_id = number;
			}
		}
		
		else if(matcherName.equals("DateMatcher")){
			if(curReceipt == null){
				curReceipt = new Receipt();
			}
			curReceipt.receipt_time = DateFormatter.format(curEle);
		}
		
		else if(matcherName.equals("CostMatcher")){
			if(curReceipt == null){
				curReceipt = new Receipt();
			}
			
			//clear cost value
			Pattern filter = Pattern.compile("[^0-9.]");
			Matcher mtc = filter.matcher(curEle);
			String data = mtc.replaceAll("");
			if(data.startsWith(".") || data.endsWith(".")){
				return curReceipt;
			}
			if(data.split(".").length > 2){
				return curReceipt;
			}
			double cost = Double.parseDouble(data);
			
			String[] regexps_sub = {".*sub[-]?total.*"};
			String[] regexps_total = {".*total.*"};
			String[] regexps_tax = {".* tax .*"};
			String[] regexps_pureNo = {"^[0-9]+$"};
			String[] regexps_otherCost = {".*shipping.*"};
			String[] regexps_cutDownCost = {".*gift card.*"};
			
			//match subtotal
			if(Matchers.freeMatch(regexps_sub, curEle, false) 
				|| Matchers.freeMatch(regexps_sub, pageEle.get(curEleIndex - 1), false)){
				curReceipt.sub_total_cost = cost;
				
				tmp = pageEle.get(curEleIndex).split(" ");
				String mark = tmp[tmp.length - 1].substring(0,1);
				if(mark.equals("-")){
					mark = tmp[tmp.length - 1].substring(1,2);
				}
				if(!Matchers.freeMatch(regexps_pureNo, mark, false)){
					curReceipt.currency_mark = mark;
				}
			}
			//match total
			else if(Matchers.freeMatch(regexps_total, curEle, false) 
				|| Matchers.freeMatch(regexps_total, pageEle.get(curEleIndex - 1), false)){
				curReceipt.total_cost = cost;
			}
			//match tax
			else if(Matchers.freeMatch(regexps_tax, curEle, false) 
					|| Matchers.freeMatch(regexps_tax, pageEle.get(curEleIndex - 1), false)){
				curReceipt.tax = cost;
			}
			//extra cost, eg., shipping fee
			else if(Matchers.freeMatch(regexps_otherCost, curEle, false) 
					|| Matchers.freeMatch(regexps_otherCost, pageEle.get(curEleIndex - 1), false)){
				curReceipt.extra_cost = cost;
			}
			else if(Matchers.freeMatch(regexps_cutDownCost, curEle, false) 
					|| Matchers.freeMatch(regexps_cutDownCost, pageEle.get(curEleIndex - 1), false)){
				curReceipt.cut_down_cost = cost;
			}
			//match item
			else{
				for(int i = curEleIndex; i >= curEleIndex - 4 && i >= 1; i --){
					if(Matchers.freeMatch(regexps_pureNo, pageEle.get(i - 1), false)){
						ReceiptItem item = new ReceiptItem();
						item.item_price = cost;
						item.item_name = pageEle.get(i);
						item.item_qty = Integer.parseInt(pageEle.get(i - 1));
						curReceipt.items.add(item);
						break;
					}
				}
			}
		}
		return curReceipt;
	}
	
	/**
	 * 
	 * @param args[0] user account
	 * @param args[1] email root path
	 * @param args[2] log path
	 */
	public static void main(String[] args){
		//Parser p = new Parser("yaxingc", "mails", "");
		Parser p = new Parser(args[0], args[1], args[2]);
		p.parseEmails();
	}
	
}
