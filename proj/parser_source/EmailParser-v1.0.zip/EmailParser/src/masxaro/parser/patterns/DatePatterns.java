package masxaro.parser.patterns;

public class DatePatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		this.addInvokePattern(".*date:.*");
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".*[0-9]+/[0-9]+/[0-9]+.*");
		this.addvaluePattern(".*[0-9]+-[0-9]+-[0-9]+.*");
	}
}
