package masxaro.parser.patterns;

public class CostPatterns extends Patterns {

	@Override
	protected void buildInvokePatterns() {
		this.addInvokePattern(".*[$]+.*");
		this.addInvokePattern(".*USD.*");
	}
	
	@Override
	protected void buildValuePatterns() {
		this.addvaluePattern(".*([0-9.,]*).*");
	}
	
}
