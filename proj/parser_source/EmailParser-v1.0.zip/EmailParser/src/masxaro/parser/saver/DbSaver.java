package masxaro.parser.saver;

import java.sql.*;

import masxaro.parser.tool.Log;
import masxaro.parser.entity.*;

public class DbSaver extends Saver {
	
	private String DB_URL = "jdbc:mysql://50.19.213.157";
	private String DB_USER = "w3t";
	private String DB_PWD = "w3t";
	private String DB_NAME = "w3tdb";
	private Connection DB_CON = null;

	private boolean jdbcInit() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			this.DB_CON = this.getConnection();
			this.selectDatabase();
		}catch(Exception e){
			Log.writeLog("JDBC init failed.");
			return false;
		}
		return true;
	}
	
	private Connection getConnection() {
		Connection con = null;
		try{
		    con =
		    	 DriverManager.getConnection(
		    	 DB_URL, DB_USER, DB_PWD);
		    Log.writeLog("db connected.");
		} catch(Exception e) {
			Log.writeLog("JDBC Exception.");
		}
		return con;
	 }
	
	private void selectDatabase(){
		try {
			Statement sql = this.DB_CON.createStatement();
			sql.execute("use " + this.DB_NAME);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return;
	}
	
	private String basicStatementBuilder() {
		Log.writeLog("Building basic info sql statement...");
		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO `receipt` (" +
				"`store_define_id`," +
				"`store_account`," +
				"`user_account`," +
				"`receipt_time`," +
				"`sub_total_cost`," +
				"`cut_down_cost`," +
				"`extra_cost`," +
				"`tax`," +
				"`total_cost`," +
				"`currency_mark`," +
				"`source`) VALUES");
		
		for(Receipt r : this.receipts) {
			sql.append("(");
			if(r.store_define_id != null) {
				r.store_define_id = "'" + r.store_define_id + "'";
			}
			else {
				r.store_define_id = "'NULL'";
			}
			sql.append(r.store_define_id + ",");
			
			if(r.store_account != null) {
				r.store_account = "'" + r.store_account + "'";
			}
			else {
				r.store_account = "'NULL'";
			}
			sql.append(r.store_account + ",");
			
			if(r.user_account != null) {
				r.user_account = "'" + r.user_account + "'";
			}
			else {
				r.user_account = "'NULL'";
			}
			sql.append(r.user_account + ",");
			
			if(r.receipt_time != null) {
				r.receipt_time = "'" + r.receipt_time + "'";
			}
			else {
				r.store_define_id = "'NULL'";
			}
			sql.append(r.receipt_time + ",");
			sql.append(r.sub_total_cost + ",");
			sql.append(r.cut_down_cost + ",");
			sql.append(r.extra_cost + ",");
			sql.append(r.tax + ",");
			sql.append(r.total_cost + ",");
			
			if(!r.currency_mark.equals("NULL")) {
				r.currency_mark = "'" + r.currency_mark + "'";
			}
			sql.append(r.currency_mark + ",");
			sql.append(r.source);
			sql.append("),");
		}
		
		return sql.substring(0, sql.length() - 1);
	}
	
	private String itemStatementBuilder(int receiptId, Receipt curReceipt) {
		Log.writeLog("Building item inserting sql...");
		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO `receipt_item` (" +
				"`receipt_id`," +
				"`item_id`," +
				"`item_name`," +
				"`item_qty`," +
				"`item_discount`," +
				"`item_price`) VALUES");
		
		for(ReceiptItem item : curReceipt.items) {
			sql.append("(");
			sql.append(receiptId + ",");
			sql.append(item.item_id + ",");
			sql.append("'" + item.item_name + "',");
			sql.append(item.item_qty + ",");
			sql.append(item.item_discount + ",");
			sql.append(item.item_price + "),");
		}
		
		return sql.substring(0, sql.length() - 1);
	}
	
	private ResultSet saveBasic() throws SQLException {
		String sql = this.basicStatementBuilder();
		//System.out.println(sql);
		
		Log.writeLog("Inserting Basic data...");
		Statement stat = this.DB_CON.createStatement();
		stat.execute(sql);
		return stat.getGeneratedKeys();
	}
	
	private void saveItems(ResultSet insertedIds) throws SQLException {
		
		while(insertedIds.next()) {
			int curReceiptId = insertedIds.getInt(1);
			String sql = this.itemStatementBuilder(curReceiptId, receipts.get(insertedIds.getRow() - 1));
			//System.out.println(sql);
			Statement exec = this.DB_CON.createStatement();
			exec.execute(sql);
		}
	}
	
	@Override
	public boolean save() {
		try {
			Log.writeLog("Database saving...");
			if(!this.jdbcInit()){
				return false;
			}
			
			ResultSet insertedIds = this.saveBasic();
			this.saveItems(insertedIds);

			this.DB_CON.close();
		} catch(Exception e) {
			Log.writeLog("SQL exception captchered.");
			e.printStackTrace();
			return false;
		} 
		Log.writeLog("Done.");
		return true;
	}
	
	public static void main(String[] args) {
		Saver s = new DbSaver();
		s.save();
	}
}
