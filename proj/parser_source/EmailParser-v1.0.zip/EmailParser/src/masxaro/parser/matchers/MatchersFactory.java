package masxaro.parser.matchers;

public class MatchersFactory {
	protected Matchers matcher;
	
	protected int matchersNumber = 3;
	
	public int getMatchersNumber() {
		return this.matchersNumber;
	}
	
	public Matchers getMatcher(int option) {
		
		switch(option){
		case 0:
			this.matcher = new ReceiptNoMatcher();
			break;
		case 1:
			this.matcher = new CostMatcher();
			break;
		case 2:
			this.matcher = new DateMatcher();
			break;
		default:
			this.matcher = null;
			break;
		}
		return this.matcher;
	}
}
