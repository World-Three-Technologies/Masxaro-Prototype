package masxaro.parser.tool;

import java.util.ArrayList;
import java.util.regex.*;

public class DateFormatter {
	protected static ArrayList<Pattern> datePatterns = new ArrayList<Pattern>();
	
	protected static void patternsBuilder(){
		datePatterns.add(Pattern.compile("[0-9][0-9]/[0-9][0-9]/[0-9][0-9]"));
	}
	
	public static String format(String date){
		patternsBuilder();
		for(int i = 0; i < datePatterns.size(); i ++){
			Matcher match = datePatterns.get(i).matcher(date);
			if(match.matches()){
				switch(i){
				case 0:
					String[] tmp = date.split("/");
					date = "20" + tmp[2] + "-" + tmp[0] + "-" + tmp[1];
					break;
				default:
					break;
				}
			}
		}
		return date;
	}
}
