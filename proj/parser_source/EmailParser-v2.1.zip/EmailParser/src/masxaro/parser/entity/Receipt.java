package masxaro.parser.entity;

import java.util.*;
public class Receipt {
	public String id = null;
	public String store_define_id = null;
	public String store_account = null;
	public String user_account = null;
	public String receipt_time = null;
	public double sub_total_cost = 0;
	public double cut_down_cost = 0;
	public double extra_cost = 0;
	public double tax = 0;
	public double total_cost = 0;
	public String currency_mark = "'$'";
	public String source = "'email'";
	public String img = null;
	public int deleted = 0;
	
	//additional info
	public ArrayList<ReceiptItem> items = new ArrayList<ReceiptItem>();
	public ArrayList<String> tags = new ArrayList<String>();
}
