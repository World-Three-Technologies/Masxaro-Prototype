package masxaro.parser.entity;

public class ReceiptItem {
	public String receipt_id;
	public String item_id = null;
	public String item_name;
	public int item_qty = 1;
	public double item_discount = 0;
	public double item_price = 0;
	public int deleted = 0;
}
