package masxaro.parser.matchhandler.costhandler;

import java.util.ArrayList;

import masxaro.parser.entity.Receipt;
import masxaro.parser.matchers.Matchers;
import masxaro.parser.matchers.MatchersFactory;

public class CutDownCostHandler extends CostHandler {
	public CutDownCostHandler(ArrayList<String> pageEle, Receipt curReceipt, 
			int curEleIndex, double cost, MatchersFactory mfac, Matchers curMatcher) {
		super(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
	}
	
	@Override
	public Receipt costHandle() {
		curReceipt.cut_down_cost = cost;
		return curReceipt;
	}
}
