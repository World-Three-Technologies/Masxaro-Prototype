package masxaro.parser.matchhandler.costhandler;

import java.util.ArrayList;

import masxaro.parser.entity.Receipt;
import masxaro.parser.entity.ReceiptItem;
import masxaro.parser.matchers.Matchers;
import masxaro.parser.matchers.MatchersFactory;

public class ItemPriceCostHandler extends CostHandler {
	public ItemPriceCostHandler(ArrayList<String> pageEle, Receipt curReceipt, 
			int curEleIndex, double cost, MatchersFactory mfac, Matchers curMatcher) {
		super(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
	}
	
	@Override
	public Receipt costHandle() {
		curMatcher = mfac.getMatcher(MatchersFactory.PURE_NO);
		for(int i = curEleIndex; i >= curEleIndex - 4 && i >= 1; i --){
			if(curMatcher.match(pageEle.get(i - 1), false, false)){
				ReceiptItem item = new ReceiptItem();
				item.item_price = cost;
				item.item_name = pageEle.get(i).replace("\"", "");
				item.item_qty = Integer.parseInt(pageEle.get(i - 1));
				curReceipt.items.add(item);
				break;
			}
		}
		return curReceipt;
	}
}
