package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class SubtotalMatcher extends Matchers {
	public SubtotalMatcher(){
		super(new SubtotalPatterns());
	}
}
