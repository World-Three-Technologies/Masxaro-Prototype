package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class ExtraCostMatcher extends Matchers {
	public ExtraCostMatcher() {
		super(new ExtraCostPatterns());
	}
}
