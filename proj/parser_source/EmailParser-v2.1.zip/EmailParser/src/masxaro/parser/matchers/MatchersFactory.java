package masxaro.parser.matchers;

public class MatchersFactory {
	public static int RECEIPT_NO = 0;
	public static int COST = 1;
	public static int DATE = 2;
	public static int CUT_DOWN_COST = 3;
	public static int EXTRA_COST = 4;
	public static int PURE_NO = 5;
	public static int SUB_TOTAL_COST = 6;
	public static int TAX = 7;
	public static int TOTAL_COST = 8;
	public static int ITEM_COST = -1;
	
	protected Matchers matcher;
	
	//Finite status machine's matcher qty
	protected int FSMMatchersQty = 3;
	
	public int getFSMMatchersQty() {
		return this.FSMMatchersQty;
	}
	
	public Matchers getMatcher(int option) {
		
		switch(option){
		case 0:
			this.matcher = new ReceiptNoMatcher();
			break;
		case 1:
			this.matcher = new CostMatcher();
			break;
		case 2:
			this.matcher = new DateMatcher();
			break;
		case 3:
			this.matcher = new CutDownCostMatcher();
			break;
		case 4:
			this.matcher = new ExtraCostMatcher();
			break;
		case 5:
			this.matcher = new PureNoMatcher();
			break;
		case 6:
			this.matcher = new SubtotalMatcher();
			break;
		case 7:
			this.matcher = new TaxMatcher();
			break;
		case 8:
			this.matcher = new TotalCostMatcher();
			break;
		default:
			this.matcher = null;
			break;
		}
		return this.matcher;
	}
}
