package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class CostMatcher extends Matchers {
	public CostMatcher(){
		super(new CostPatterns());
	}
}
