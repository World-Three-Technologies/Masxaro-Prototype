package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class DateMatcher extends Matchers {
		public DateMatcher(){
			super(new DatePatterns());
		}
}
