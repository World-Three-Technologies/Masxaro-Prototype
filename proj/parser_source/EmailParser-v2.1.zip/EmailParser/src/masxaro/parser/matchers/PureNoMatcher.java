package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class PureNoMatcher extends Matchers {
	public PureNoMatcher() {
		super(new PureNoPatterns());
	}
}
