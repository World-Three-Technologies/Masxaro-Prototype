package masxaro.parser.saver;

import java.io.*;

import masxaro.parser.entity.*;
import masxaro.parser.tool.Log;

public class FileSaver extends Saver {
	
	@Override
	public boolean save() {
		File root = new File(this.rootPath);
		if(!root.exists() || !root.isDirectory()){
			return false;
		}
		try{
			for(Receipt r : this.receipts){
				if(r.store_define_id == null){
					continue;
				}
				Log.writeLog("File saving: receipt#-" + r.store_define_id);
				File curR = new File(this.rootPath + "/" + r.store_define_id);
				if(!curR.exists()){
					curR.createNewFile();
				}
				else{
					curR.delete();
					curR.createNewFile();
				}
				BufferedWriter in = new BufferedWriter(new FileWriter(curR));
				in.write("==========================================\n");
				in.write("receipt id: " + r.store_define_id + "\n");
				in.write("receipt time: " + r.receipt_time + "\n");
				in.write("store account: " + r.store_account + "\n");
				in.write("user account: " + r.user_account + "\n");
				in.write("sub total: " + r.currency_mark + r.sub_total_cost + "\n");
				in.write("other fee: " + r.currency_mark + r.extra_cost + "\n");
				in.write("cut down fee: " + r.currency_mark + r.cut_down_cost + "\n");
				in.write("tax: " + r.currency_mark + r.tax + "\n");
				in.write("total: " + r.currency_mark + r.total_cost + "\n");
				in.write("-.-.-.-.-.-items:-.-.-.-.-.-.-\n");
				for(ReceiptItem ri : r.items){
					in.write("item: " + ri.item_name + "\n");
					in.write("itemQty: " + ri.item_qty + "\n");
					in.write("item price: " + ri.item_price + "\n");
					in.write("|||||||||||||||||||||\n");
				}
				in.close();
			}
		}catch(Exception e){
			Log.writeLog("File saving error.");
			return false;
		}
		Log.writeLog("File saving done.");
		return true;
	}
}
