package masxaro.parser.patterns;

public class TaxPatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".* tax .*");
	}
}
