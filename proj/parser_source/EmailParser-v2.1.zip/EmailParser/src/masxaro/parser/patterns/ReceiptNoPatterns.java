package masxaro.parser.patterns;


public class ReceiptNoPatterns extends Patterns {
	
	@Override
	protected void buildInvokePatterns(){
		this.addInvokePattern("Order #:.*");
		this.addInvokePattern("Order Number:.*");
		this.addInvokePattern("Purchase Confirmation Number:.*");
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".*[:]?[a-zA-Z0-9-]+");
	}
}
