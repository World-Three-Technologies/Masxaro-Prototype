package masxaro.parser.patterns;

public class SubtotalPatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".*sub[-_]?total.*");
	}
}
