package masxaro.parser.patterns;

public class CutDownCostPatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".*gift card.*");
	}
}
