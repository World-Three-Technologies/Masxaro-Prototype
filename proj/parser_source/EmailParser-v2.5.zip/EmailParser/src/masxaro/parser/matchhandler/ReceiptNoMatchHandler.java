package masxaro.parser.matchhandler;

import java.util.ArrayList;
import java.util.regex.*;

import masxaro.parser.entity.*;
import masxaro.parser.patterns.*;
import masxaro.parser.matchers.*;

public class ReceiptNoMatchHandler extends MatchHandler {
	public ReceiptNoMatchHandler(ArrayList<Receipt> receipts, ArrayList<String> pageEle, 
			Receipt curReceipt, int curEleIndex, String userAcc) {
		super(receipts, pageEle, curReceipt, curEleIndex, userAcc);
	}
	
	@Override
	public Receipt handle() {
		String[] tmp = null;
		String number = null;
		
		Pattern delimeter = Pattern.compile("number", Pattern.CASE_INSENSITIVE);
		Matcher mt = delimeter.matcher(curEle);
		curEle = mt.replaceFirst(":::");
		
		String[] splitDeli1 = curEle.split(":");
		String[] splitDeli2 = curEle.split("#");
		String[] splitDeli3 = curEle.split(":::");
		
		tmp = splitDeli1.length > 1 ? splitDeli1 : (splitDeli2.length > 1 ? splitDeli2 : splitDeli3);
		number = tmp[tmp.length - 1].trim();
		
		if(curReceipt != null){
			if(curReceipt.store_define_id == null){
				curReceipt.store_define_id  = number;
			}
			if(!curReceipt.items.isEmpty()){
				this.appendReceipt(curReceipt);
				curReceipt = null;
			}
		}
		
		if(curReceipt == null){
			curReceipt = new Receipt();
			curReceipt.store_define_id = number;
		}
		return curReceipt;
	}
}
