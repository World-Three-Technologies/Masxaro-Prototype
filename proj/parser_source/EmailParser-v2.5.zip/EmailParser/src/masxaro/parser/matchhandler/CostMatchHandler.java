package masxaro.parser.matchhandler;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import masxaro.parser.entity.*;
import masxaro.parser.matchers.*;
import masxaro.parser.matchhandler.costhandler.*;

public class CostMatchHandler extends MatchHandler {
	
	public CostMatchHandler(ArrayList<Receipt> receipts, ArrayList<String> pageEle, 
			Receipt curReceipt, int curEleIndex, String userAcc) {
		super(receipts, pageEle, curReceipt, curEleIndex, userAcc);
		
	}
	
	@Override
	public Receipt handle() {
		CostHandler costH = null;
		
		if(curReceipt == null){
			curReceipt = new Receipt();
		}
		
		//clear cost value
		Pattern filter = Pattern.compile("[^0-9.]");
		Matcher mtc = filter.matcher(curEle);
		String data = mtc.replaceAll("");
		if(data.startsWith(".") || data.endsWith(".")){
			return curReceipt;
		}
		if(data.split(".").length > 2){
			return curReceipt;
		}
		double cost = Double.parseDouble(data);
		
		//match subtotal
		costH = this.costHandlerFactory(MatchersFactory.SUB_TOTAL_COST, cost);
		if(costH != null) {
			return costH.costHandle();
		}
		
		//match total
		costH = this.costHandlerFactory(MatchersFactory.TOTAL_COST, cost);
		if(costH != null) {
			return costH.costHandle();
		}
		//match tax
		costH = this.costHandlerFactory(MatchersFactory.TAX, cost);
		if(costH != null) {
			return costH.costHandle();
		}
		//extra cost, eg., shipping fee
		costH = this.costHandlerFactory(MatchersFactory.EXTRA_COST, cost);
		if(costH != null) {
			return costH.costHandle();
		}
		//cut down cost
		costH = this.costHandlerFactory(MatchersFactory.CUT_DOWN_COST, cost);
		if(costH != null) {
			return costH.costHandle();
		}
		//match item
		else{
			costH = this.costHandlerFactory(MatchersFactory.ITEM_COST, cost);
			return costH.costHandle();
		}
	}
	
	private CostHandler costHandlerFactory(int matcherId, double cost) {
		MatchersFactory mfac = new MatchersFactory();
		Matchers curMatcher = mfac.getMatcher(matcherId);
		
		if(matcherId == MatchersFactory.ITEM_COST) {
			return new ItemPriceCostHandler(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
		}
		
		if(curMatcher.match(curEle, false, false) 
				|| curMatcher.match(prevEle, false, false)) {
			if(matcherId == MatchersFactory.SUB_TOTAL_COST) {
				return new SubtotalCostHandler(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
			} 
			if(matcherId == MatchersFactory.TOTAL_COST) {
				return new TotalCostHandler(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
			}
			if(matcherId == MatchersFactory.TAX) {
				return new TaxCostHandler(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
			}
			if(matcherId == MatchersFactory.EXTRA_COST) {
				return new ExtraCostHandler(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
			}
			if(matcherId == MatchersFactory.CUT_DOWN_COST) {
				return new CutDownCostHandler(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
			}
		}
		
		return null;
	}
}
