package masxaro.parser.matchhandler;

import java.util.ArrayList;

import masxaro.parser.entity.*;

public abstract class MatchHandler {
	protected String curEle;
	protected String prevEle;
	protected ArrayList<String> pageEle;
	protected Receipt curReceipt;
	protected int curEleIndex;
	protected String userAcc;
	protected ArrayList<Receipt> receipts;
	
	protected MatchHandler(ArrayList<Receipt> receipts, ArrayList<String> pageEle, 
			Receipt curReceipt, int curEleIndex, String userAcc) {
		this.receipts = receipts;
		this.pageEle = pageEle;
		this.curReceipt = curReceipt;
		this.curEleIndex = curEleIndex;
		this.userAcc = userAcc;
		
		this.curEle = pageEle.get(curEleIndex);
		this.prevEle = pageEle.get(curEleIndex - 1);
	} 
	
	protected void appendReceipt(Receipt receipt) {
		if(receipt.user_account == null) {
			receipt.user_account = this.userAcc;
		}
		
		this.receipts.add(receipt);
	}
	
	public abstract Receipt handle();
}
