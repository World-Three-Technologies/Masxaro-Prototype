package masxaro.parser.matchhandler;

import java.util.ArrayList;

import masxaro.parser.entity.Receipt;

public class NewReceiptMatchHandler extends MatchHandler {
	public NewReceiptMatchHandler(ArrayList<Receipt> receipts, ArrayList<String> pageEle, 
			Receipt curReceipt, int curEleIndex, String userAcc) {
		super(receipts, pageEle, curReceipt, curEleIndex, userAcc);
	}
	
	@Override
	public Receipt handle() {
		if(curReceipt != null && curReceipt.store_define_id != null) {
			String idTmp = curReceipt.store_define_id;
			curReceipt = new Receipt();
			curReceipt.store_define_id = idTmp;
		}
		return curReceipt;
	}
}
