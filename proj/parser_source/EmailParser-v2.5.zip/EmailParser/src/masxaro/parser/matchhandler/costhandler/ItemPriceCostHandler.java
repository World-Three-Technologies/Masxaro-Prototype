package masxaro.parser.matchhandler.costhandler;

import java.util.ArrayList;

import masxaro.parser.entity.Receipt;
import masxaro.parser.entity.ReceiptItem;
import masxaro.parser.matchers.Matchers;
import masxaro.parser.matchers.MatchersFactory;

public class ItemPriceCostHandler extends CostHandler {
	public ItemPriceCostHandler(ArrayList<String> pageEle, Receipt curReceipt, 
			int curEleIndex, double cost, MatchersFactory mfac, Matchers curMatcher) {
		super(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
	}
	
	@Override
	public Receipt costHandle() {
		curMatcher = mfac.getMatcher(MatchersFactory.PURE_NO);
		boolean found = false;
		for(int i = curEleIndex; i >= curEleIndex - 3 && i >= 1; i --){
			if(curMatcher.match(pageEle.get(i - 1), false, false)){
				int qty = 0;
				try{
					qty = Integer.parseInt(pageEle.get(i - 1));
				}catch(NumberFormatException e) {
					continue;
				}
				
				ReceiptItem item = new ReceiptItem();
				item.item_price = cost;
				item.item_name = pageEle.get(i).replace("\"", "");
				item.item_qty = qty;
				curReceipt.items.add(item);
				found  = true;
				break;
			}
		}
		if(!found) {
			ReceiptItem item = new ReceiptItem();
			item.item_price = cost;
			item.item_name = pageEle.get(curEleIndex - 3).replace("\"", "");
			item.item_qty = 1;
			curReceipt.items.add(item);
		}
		return curReceipt;
	}
}