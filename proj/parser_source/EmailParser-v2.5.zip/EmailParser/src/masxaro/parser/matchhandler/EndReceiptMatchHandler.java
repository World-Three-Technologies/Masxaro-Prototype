package masxaro.parser.matchhandler;

import java.util.ArrayList;

import masxaro.parser.entity.*;
import masxaro.parser.tool.*;

public class EndReceiptMatchHandler extends MatchHandler {
	public EndReceiptMatchHandler(ArrayList<Receipt> receipts, ArrayList<String> pageEle, 
			Receipt curReceipt, int curEleIndex, String userAcc) {
		super(receipts, pageEle, curReceipt, curEleIndex, userAcc);
	}
	
	@Override
	public Receipt handle() {
		if(curReceipt != null) {
			this.appendReceipt(curReceipt);
		}
		return null;
	}
}
