package masxaro.parser;
import java.util.*;
import java.util.regex.*;
import java.io.*;

import masxaro.parser.entity.*;
import masxaro.parser.matchers.*;
import masxaro.parser.tool.*;
import masxaro.parser.saver.*;
import masxaro.parser.matchhandler.*;


public class Parser {
	private String userAcc;
	private File[] fileList;
	private ArrayList<Receipt> receipts;
	private String rootPath;
	
	Parser(String userAcc_init, String email_root, String log_path){
		this.userAcc = userAcc_init;
		this.receipts = new ArrayList<Receipt>();
		this.rootPath = email_root + "/" + this.userAcc;
		Log.setLogRoot(log_path);
	}
	
	protected void saveDb() {
		Saver saver = new DbSaver();
		saver.set(this.rootPath, this.receipts);
		saver.save();
	}
	
	protected void saveFile() {
		Saver saver = new FileSaver();
		saver.set(this.rootPath, this.receipts);
		saver.save();
	}
	
	protected void appendReceipt(Receipt receipt) {
		if(receipt.user_account == null) {
			receipt.user_account = this.userAcc;
		}
		
		this.receipts.add(receipt);
	}
	
	/**
	 * fetch PHP grabbed emails
	 */
	public boolean fetchNewEmails(){
		try{
			File target = new File(this.rootPath);
			if(target.isDirectory() && target.exists()){
				if((this.fileList = target.listFiles()) == null || this.fileList.length == 0){
					Log.writeLog("No emails in: " + this.rootPath);
					return false;
				}
				Log.writeLog("Fetch emails in: " + this.rootPath);
			}
			else{
				Log.writeLog("Cannot find directory: " + this.rootPath);
				return false;
			}
		}catch(Exception e){
			Log.writeLog("Fetch emails error: File error.");
			return false;
		}
		return true;
	}
	
	/**
	 * @todo delete file after parsed
	 * FSM(1)
	 * parse start
	 */
	public void parseEmails(){
		if(!this.fetchNewEmails()){
			return;
		}
		try{
			for(File file : this.fileList){
				String from = file.getName().split(":::")[0];
				Log.writeLog("Parsing " + file.getName() + " ...");
				this.parseReceipts(this.parseHTML(file), from);
				//Log.writeLog(file.getName() + " Parse done. Delete file");
				file.delete();
			}
			this.saveDb();
			//this.saveFile();
			//this.parseReceipts(this.parseHTML(new File("mails/w3tAcc/test")));
		}catch(Exception e){
			e.printStackTrace();
			Log.writeLog("Parse file exception.");
		}
		return;
	}
	
	/**
	 * FSM(2)
	 * @param File page html page
	 * 
	 * 
	 * @return ArrayList<String> pageEle all non-html, text elements with receipt informations
	 * 
	 * @desc
	 * this function will eliminate all html elements in an html file and pick out all text words
	 * and organize them into an arraylist.
	 */
	protected ArrayList<String> parseHTML(File file){
		ArrayList<String> pageEle = new ArrayList<String>();
		try{
			BufferedReader in = new BufferedReader(new FileReader(file));
			String tmp;
			StringBuilder page = new StringBuilder();
			while((tmp = in.readLine()) != null){
				page.append(tmp);
			}
			in.close();
			
			String curPage = page.toString();
			String regexp_receipt = ".*receipt.*";
			String regexp_order = ".*order.*";
			if(!curPage.matches(regexp_order) && curPage.matches(regexp_receipt)){
				return null;
			}
			
			String regexp = ">([^<>]+)<";
			Pattern reg = Pattern.compile(regexp);
			Matcher mtch = reg.matcher(curPage);
			while(mtch.find()){
				String cur = mtch.group();
				cur = cur.substring(1, cur.length() - 1).trim();
				if(cur == null || cur.length() == 0){
					continue;
				}
				pageEle.add(cur);
			}
		}catch(Exception e){
			Log.writeLog("ParseHTML error.");
			return null;
			//e.printStackTrace();
		}
		return pageEle;
	}
	
	/**
	 * FSM(3)
	 * @todo
	 * finish all patterns, cost patterns, and separately match different costs.
	 * 
	 * @param ArrayList<String> pageEle
	 * @param String from store account
	 * @return ArrayList<ReceiptEnty> receipts
	 * 
	 * @desc
	 * parse receipts from one parsed pageEle arraylist of one html email
	 */
	protected void parseReceipts(ArrayList<String> pageEle, String from){
		if(pageEle == null){
			return;
		}
		ArrayList<Matchers> matchers = new ArrayList<Matchers>();
		
		MatchersFactory matcherFac = new MatchersFactory();
		
		for(int i = 0; i < matcherFac.getFSMMatchersQty(); i ++){
			matchers.add(matcherFac.getMatcher(i));
		}
		
		boolean searchingInvoke = true;
		int curMatcherIndex = 0;
		Receipt curReceipt = null;
		
		for(int curEleIndex = 0; curEleIndex < pageEle.size(); curEleIndex ++){
			curMatcherIndex = searchingInvoke ? 0 : curMatcherIndex;
			int nextEleIndex = curEleIndex + 1;
			for(; curMatcherIndex < matchers.size();){
				if(searchingInvoke){
					if(matchers.get(curMatcherIndex).match(pageEle.get(curEleIndex), true, false)){
						searchingInvoke = false;
						curEleIndex --;
						break;
					}
					curMatcherIndex ++;
				}
				else{
					int matchedStatus = -1;
					if(matchers.get(curMatcherIndex).match(pageEle.get(curEleIndex), false, false)){
						matchedStatus = 0;
					}
					else if(matchers.get(curMatcherIndex).match(pageEle.get(nextEleIndex), false, false)) {
						matchedStatus = 1;
					}
					if (matchedStatus >= 0) {
						if(curReceipt != null){
							curReceipt.store_account = from;
						}
						int index = matchedStatus == 0 ? curEleIndex : nextEleIndex;
						curReceipt = valueHandler(matchers.get(curMatcherIndex), pageEle, curReceipt, index);
					}
					searchingInvoke = true;
					break;
				}
			}
		}
		
		if(curReceipt != null){
			this.appendReceipt(curReceipt);
		}
	}
	
	/**
	 * FSM(4)
	 * handling logic after value matched
	 */
	protected Receipt valueHandler(Matchers matchedMatcher, ArrayList<String> pageEle, 
									Receipt curReceipt, int curEleIndex) {
		MatchHandler mHandler = null;
		String matcherName = matchedMatcher.getClass().getName();
		matcherName = matcherName.substring(matcherName.lastIndexOf(".") + 1, matcherName.length());
		
		if(matcherName.equals("ReceiptNoMatcher")){
			mHandler = new ReceiptNoMatchHandler(this.receipts, pageEle, curReceipt, curEleIndex, this.userAcc);
		}
		
		else if(matcherName.equals("DateMatcher")){
			mHandler = new DateMatchHandler(this.receipts, pageEle, curReceipt, curEleIndex, this.userAcc);
		}
		
		else if(matcherName.equals("NewReceiptMatcher")){
			mHandler = new NewReceiptMatchHandler(this.receipts, pageEle, curReceipt, curEleIndex, this.userAcc);
		}
		
		else if(matcherName.equals("CostMatcher")){
			mHandler = new CostMatchHandler(this.receipts, pageEle, curReceipt, curEleIndex, this.userAcc);
		}
		
		else if(matcherName.equals("EndReceiptMatcher")){
			mHandler = new EndReceiptMatchHandler(this.receipts, pageEle, curReceipt, curEleIndex, this.userAcc);
		}
		
		return mHandler.handle();
	}
	
	/**
	 * 
	 * @param args[0] user account
	 * @param args[1] email root path
	 * @param args[2] log path
	 */
	public static void main(String[] args){
		//Parser p = new Parser("yaxingc", "mails", "");
		Parser p = new Parser(args[0], args[1], args[2]);
		p.parseEmails();
	}
	
}
