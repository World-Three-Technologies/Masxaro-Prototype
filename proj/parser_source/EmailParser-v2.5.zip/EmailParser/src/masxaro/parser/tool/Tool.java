package masxaro.parser.tool;

import java.util.regex.*;
import java.util.*;

public class Tool {
	
}
