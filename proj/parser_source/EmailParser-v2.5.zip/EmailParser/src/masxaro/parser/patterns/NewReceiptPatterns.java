package masxaro.parser.patterns;

public class NewReceiptPatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		this.addInvokePattern(".*purchase summary.*");
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".*purchase summary.*");
	}
}
