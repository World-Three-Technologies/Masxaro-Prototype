package masxaro.parser.patterns;

import java.util.*;
public abstract class Patterns {
	protected ArrayList<String> invokePatterns;
	protected ArrayList<String> valuePatterns;
	
	Patterns(){
		this.invokePatterns = new ArrayList<String>();
		this.valuePatterns = new ArrayList<String>();
		
		this.buildInvokePatterns();
		this.buildValuePatterns();
	}
	
	public boolean addInvokePattern(String newPattern){
		return this.invokePatterns.add(newPattern);
	}

	public boolean addvaluePattern(String newPattern){
		return this.valuePatterns.add(newPattern);
	}
	
	public boolean deleteInvokePattern(int index){
		return this.invokePatterns.remove(index) == null ? false : true;
	}
	
	public boolean deleteValuePattern(int index){
		return this.valuePatterns.remove(index) == null ? false : true;
	}
	
	public ArrayList<String> getInvokePatterns(){
		return this.invokePatterns;
	}
	
	public ArrayList<String> getValuePatterns(){
		return this.valuePatterns;
	}
	
	/**
	 * 
	 * build certain invoke patterns use add func
	 */
	abstract protected void buildInvokePatterns();
	
	/**
	 * 
	 * build certain value patterns use add func
	 */
	abstract protected void buildValuePatterns();
}
