package masxaro.parser.patterns;

public class PureNoPatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern("^[0-9]+$");
	}
}
