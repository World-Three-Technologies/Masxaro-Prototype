package masxaro.parser.patterns;

public class EndReceiptPatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		this.addInvokePattern("Billing / Delivery information");
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern("Billing / Delivery information");
	}
}
