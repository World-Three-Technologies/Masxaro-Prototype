package masxaro.parser.patterns;


public class ReceiptNoPatterns extends Patterns {
	
	@Override
	protected void buildInvokePatterns(){
		this.addInvokePattern("order #:.*");
		this.addInvokePattern("order number:.*");
		this.addInvokePattern("purchase confirmation number:.*");
		this.addInvokePattern("confirmation #.*");
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".*[:]?[a-zA-Z0-9-]+");
	}
}
