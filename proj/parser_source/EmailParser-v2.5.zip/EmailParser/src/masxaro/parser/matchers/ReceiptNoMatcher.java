package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class ReceiptNoMatcher extends Matchers {
	public ReceiptNoMatcher(){
		super(new ReceiptNoPatterns());
	}
}
