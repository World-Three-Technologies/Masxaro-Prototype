package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class TaxMatcher extends Matchers {
	public TaxMatcher() {
		super(new TaxPatterns());
	}
}
