package masxaro.parser.matchers;

import masxaro.parser.patterns.EndReceiptPatterns;

public class EndReceiptMatcher extends Matchers {
	public EndReceiptMatcher(){
		super(new EndReceiptPatterns());
	}
}
