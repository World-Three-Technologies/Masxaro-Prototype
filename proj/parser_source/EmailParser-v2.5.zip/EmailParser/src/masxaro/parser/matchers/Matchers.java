package masxaro.parser.matchers;

import java.util.*;
import java.util.regex.*;
import masxaro.parser.patterns.*;

public abstract class Matchers {
	
	protected Patterns pattern;
	
	Matchers(Patterns pattern){
		this.pattern = pattern;
	}
	
	/**
	 * 
	 * @param Patterns pattern
	 * @param String target
	 * @param boolean matchInvoke true:invoke match, false: value match 
	 * @param boolean caseSensitive true:sensitive, false:insensitive 
	 * 
	 * @return boolean
	 * 
	 * @desc
	 * match all patterns given in a Patterns object
	 */
	public boolean match(String target, boolean matchInvoke, boolean caseSensitive){
		ArrayList<String> patterns = matchInvoke ? pattern.getInvokePatterns() : pattern.getValuePatterns(); 
		for(String curPattern : patterns){
			Pattern pat = caseSensitive 
						? Pattern.compile(curPattern) : Pattern.compile(curPattern, Pattern.CASE_INSENSITIVE);
			Matcher mt = pat.matcher(target);
			if(mt.matches()){
				//mt.replaceAll(target);
				return true;
			}
			else{
				continue;
			}
		}
		return false;
	}
	
	/**
	 * 
	 * @param String[] regxps
	 * @param String target
	 * @param boolean caseSensitive true:sensitive, false:insensitive
	 * @return boolean
	 * 
	 * @desc
	 * a flexible API aiming at matching an array of any customized regexps with target string
	 * any one of the regexps matched, return true
	 * @return
	 */
	public static boolean freeMatch(String[] regexps, String target, boolean caseSensitive){
		Pattern pattern;
		Matcher matcher;
		for(String reg : regexps){
			pattern = caseSensitive 
					? Pattern.compile(reg) : Pattern.compile(reg, Pattern.CASE_INSENSITIVE);
			matcher = pattern.matcher(target);
			if(matcher.matches()){
				return true;
			}
		}
		return false;
	}
	
}
