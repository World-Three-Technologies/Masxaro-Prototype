package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class CutDownCostMatcher extends Matchers {
	public CutDownCostMatcher() {
		super(new CutDownCostPatterns());
	}
}
