package masxaro.parser.matchers;

import masxaro.parser.patterns.*;

public class NewReceiptMatcher extends Matchers {
	public NewReceiptMatcher() {
		super(new NewReceiptPatterns());
	}
}
