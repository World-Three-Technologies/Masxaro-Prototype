package masxaro.parser.saver;

import java.util.ArrayList;

import masxaro.parser.entity.Receipt;

public abstract class Saver {
	protected String rootPath;
	protected ArrayList<Receipt> receipts;
	
	public void set(String rootPath, ArrayList<Receipt> receipts){
		this.rootPath = rootPath;
		this.receipts = receipts;
	}
	
	abstract public boolean save();
}
