package masxaro.parser.tool;

import java.io.*;
import java.util.*;
import java.text.*;

public class Log {
	protected static File log;
	protected static String logRoot = null;
	
	public static void setLogRoot(String path){
		logRoot = path;
	}
	
	public static File getLogFile(){
		if(log != null){
			return log;
		}
		try{
			if(logRoot == null || logRoot.length() == 0){
				log = new File("masxaroLog.log");
			}
			else{
				log = new File(logRoot + "/masxaroLog.log");
			}
			
			if(!log.exists()){
				log.createNewFile();
			}
			return log;
		}catch(Exception e){
			return null;
		}
	}
	
	protected static String getTime(){
		String NOW_FORMAT = "yyyy-MM-dd HH:mm:ss";
		Calendar cal = Calendar.getInstance();
		Date now = cal.getTime();
		SimpleDateFormat format = new SimpleDateFormat(NOW_FORMAT);
		return format.format(now);
	}
	
	public static boolean writeLog(String logInfo){
		logInfo += "\n";
		File curLog = getLogFile();
		try{
			StringBuilder content = new StringBuilder();
			String tmp;
			BufferedReader in = new BufferedReader(new FileReader(curLog));
			while((tmp = in.readLine()) != null){
				content.append(tmp);
				content.append("\n");
			}
			in.close();
			
			content.append(getTime() + ":	" + logInfo);
			BufferedWriter out = new BufferedWriter(new FileWriter(curLog));
			out.write(content.toString());
			out.close();
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static PrintWriter getWriter(){
		File curLog = getLogFile();
		try{
			return new PrintWriter(new FileWriter(curLog));
		}catch(Exception e){
			return null;
		}
	}
}
