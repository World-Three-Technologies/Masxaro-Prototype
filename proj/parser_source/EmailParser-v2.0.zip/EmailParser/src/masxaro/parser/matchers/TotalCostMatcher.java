package masxaro.parser.matchers;

import masxaro.parser.patterns.*;
public class TotalCostMatcher extends Matchers {
	public TotalCostMatcher() {
		super(new TotalCostPatterns());
	}
}
