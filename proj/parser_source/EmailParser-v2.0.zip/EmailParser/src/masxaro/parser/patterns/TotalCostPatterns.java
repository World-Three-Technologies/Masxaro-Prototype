package masxaro.parser.patterns;

public class TotalCostPatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".*total.*");
	}
}
