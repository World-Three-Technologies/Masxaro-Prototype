package masxaro.parser.patterns;

public class ExtraCostPatterns extends Patterns {
	@Override
	protected void buildInvokePatterns(){
		
	}
	
	@Override
	protected void buildValuePatterns(){
		this.addvaluePattern(".*shipping.*");
	}
}
