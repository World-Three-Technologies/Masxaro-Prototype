package masxaro.parser.matchhandler.costhandler;

import java.util.ArrayList;

import masxaro.parser.entity.Receipt;
import masxaro.parser.matchers.*;

public abstract class CostHandler {
	protected ArrayList<String> pageEle;
	protected Receipt curReceipt;
	protected int curEleIndex;
	protected double cost;
	protected MatchersFactory mfac;
	protected Matchers curMatcher;
	protected String curEle;
	protected String prevEle;
	
	protected CostHandler(ArrayList<String> pageEle, Receipt curReceipt, 
			int curEleIndex, double cost, MatchersFactory mfac, Matchers curMatcher) {
		this.pageEle = pageEle;
		this.curReceipt = curReceipt;
		this.curEleIndex = curEleIndex;
		this.cost = cost;
		this.mfac = mfac;
		this.curMatcher = curMatcher;
		
		this.curEle = pageEle.get(curEleIndex);
		this.prevEle = pageEle.get(curEleIndex - 1);
	}
	
	public abstract Receipt costHandle();
}
