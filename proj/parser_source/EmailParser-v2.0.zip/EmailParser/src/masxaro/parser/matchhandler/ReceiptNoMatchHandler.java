package masxaro.parser.matchhandler;

import java.util.ArrayList;

import masxaro.parser.entity.*;
import masxaro.parser.patterns.*;
import masxaro.parser.matchers.*;

public class ReceiptNoMatchHandler extends MatchHandler {
	public ReceiptNoMatchHandler(ArrayList<Receipt> receipts, ArrayList<String> pageEle, 
			Receipt curReceipt, int curEleIndex, String userAcc) {
		super(receipts, pageEle, curReceipt, curEleIndex, userAcc);
	}
	
	@Override
	public Receipt handle() {
		String[] tmp = curEle.split(":");
		String number = tmp[tmp.length - 1].trim();
		
		if(curReceipt != null){
			if(curReceipt.store_define_id == null){
				curReceipt.store_define_id  = number;
			}
			if(!curReceipt.items.isEmpty()){
				this.appendReceipt(curReceipt);
				curReceipt = null;
			}
		}
		
		if(curReceipt == null){
			curReceipt = new Receipt();
			curReceipt.store_define_id = number;
		}
		return curReceipt;
	}
}
