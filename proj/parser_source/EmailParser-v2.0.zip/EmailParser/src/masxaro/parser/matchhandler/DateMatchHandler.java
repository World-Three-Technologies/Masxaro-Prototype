package masxaro.parser.matchhandler;

import java.util.ArrayList;

import masxaro.parser.entity.*;
import masxaro.parser.tool.*;

public class DateMatchHandler extends MatchHandler {
	public DateMatchHandler(ArrayList<Receipt> receipts, ArrayList<String> pageEle, 
			Receipt curReceipt, int curEleIndex, String userAcc) {
		super(receipts, pageEle, curReceipt, curEleIndex, userAcc);
	}
	
	@Override
	public Receipt handle() {
		if(curReceipt == null){
			curReceipt = new Receipt();
		}
		curReceipt.receipt_time = DateFormatter.format(curEle);
		return curReceipt;
	}
}
