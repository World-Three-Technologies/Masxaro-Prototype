package masxaro.parser.matchhandler.costhandler;

import java.util.ArrayList;

import masxaro.parser.entity.Receipt;
import masxaro.parser.matchers.Matchers;
import masxaro.parser.matchers.MatchersFactory;

public class SubtotalCostHandler extends CostHandler {
	public SubtotalCostHandler(ArrayList<String> pageEle, Receipt curReceipt, 
			int curEleIndex, double cost, MatchersFactory mfac, Matchers curMatcher) {
		super(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
	}
	
	@Override
	public Receipt costHandle() {
		curReceipt.sub_total_cost = cost;
		
		String[] tmp = curEle.split(" ");
		String mark = tmp[tmp.length - 1].substring(0,1);
		if(mark.equals("-")){
			mark = tmp[tmp.length - 1].substring(1,2);
		}
		curMatcher = mfac.getMatcher(MatchersFactory.PURE_NO);
		if(!curMatcher.match(mark, false, false)){
			curReceipt.currency_mark = mark;
		}
		return curReceipt;
	}
}
