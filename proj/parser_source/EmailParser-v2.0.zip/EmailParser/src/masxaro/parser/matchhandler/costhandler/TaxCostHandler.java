package masxaro.parser.matchhandler.costhandler;

import java.util.ArrayList;

import masxaro.parser.entity.Receipt;
import masxaro.parser.matchers.Matchers;
import masxaro.parser.matchers.MatchersFactory;

public class TaxCostHandler extends CostHandler {
	public TaxCostHandler(ArrayList<String> pageEle, Receipt curReceipt, 
			int curEleIndex, double cost, MatchersFactory mfac, Matchers curMatcher) {
		super(pageEle, curReceipt, curEleIndex, cost, mfac, curMatcher);
	}
	
	@Override
	public Receipt costHandle() {
		curReceipt.tax = cost;
		return curReceipt;
	}
}
